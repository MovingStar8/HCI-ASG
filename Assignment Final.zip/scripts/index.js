const redirectologin = () => {
	return window.location.replace("./login.html");
};
const redirecttohome = () => {
	return window.location.replace("./index.html");
};
const redirectocontact = () => {
	return window.location.replace("./contactus.html");
};
